﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LoginRequest.Objects
{
    public class Usuario
    {
        public string User { get; set; }
        public string Contraseña { get; set; }

        public Usuario()
        {

        }
    }
}